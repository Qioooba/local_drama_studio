/**
 * LocalDramaStudio navigation-draft coordinator — REFERENCE IMPLEMENTATION.
 * This file is not a repository patch. Integrate only after migrating producers
 * to the contract below and implementing a synchronous, observable registry.
 * version is the local editable-payload version, NOT a database revision.
 */
export type DraftAction = "save" | "discard";
export type DraftBlocked = { status: "blocked"; reason: string };
export type DraftSaveResult = { status: "saved"; savedVersion: number } | DraftBlocked;
export type DraftDiscardResult = { status: "discarded"; discardedVersion: number } | DraftBlocked;
export type MaybePromise<T> = T | Promise<T>;

export interface DraftOwner {
  readonly ownerId: string;
  readonly entityKey: string;
  readonly registrationToken: string;
  readonly version: number;
  readonly dirty: boolean;
  readonly save?: (expectedVersion: number) => MaybePromise<DraftSaveResult>;
  readonly discard?: (expectedVersion: number) => MaybePromise<DraftDiscardResult>;
}

export interface DraftRegistryReader {
  /** Clean mounted owners must remain readable; unregister is a separate action. */
  get(ownerId: string): Readonly<DraftOwner> | undefined;
  /** Return immutable entries. Updating an entry must not mutate previous snapshots. */
  getDirty(): readonly Readonly<DraftOwner>[];
}

export type SettleResult =
  | { allowed: true; completedOwnerIds: string[] }
  | { allowed: false; code: string; reason: string; completedOwnerIds: string[] };

function sameIdentity(a: Readonly<DraftOwner>, b: Readonly<DraftOwner>): boolean {
  return a.ownerId === b.ownerId
    && a.registrationToken === b.registrationToken
    && a.version === b.version;
}

/**
 * One bounded pass. Never auto-save newly arriving edits, clear the registry,
 * or navigate from this function. The caller must recheck the live registry
 * immediately before invoking the live router blocker's proceed().
 */
export async function settleDirtyDrafts(
  registry: DraftRegistryReader,
  action: DraftAction,
): Promise<SettleResult> {
  const targets = registry.getDirty().map((owner) => ({ ...owner }));
  const completedOwnerIds: string[] = [];
  const blocked = (code: string, reason: string): SettleResult => ({
    allowed: false, code, reason, completedOwnerIds: [...completedOwnerIds],
  });

  for (const target of targets) {
    // Re-read the callback: a previous save may have refreshed the server revision
    // without changing this owner's local editable-payload version.
    const current = registry.get(target.ownerId);
    if (!current) return blocked("DRAFT_OWNER_DISAPPEARED", `“${target.entityKey}”的编辑器已变化，请重新确认。`);
    if (!sameIdentity(current, target)) return blocked("DRAFT_CHANGED", `“${target.entityKey}”产生了新修改，请重新确认。`);
    if (!current.dirty) continue;

    let result: DraftSaveResult | DraftDiscardResult;
    try {
      if (action === "save") {
        if (!current.save) return blocked("DRAFT_SAVE_UNSUPPORTED", `请回到“${target.entityKey}”完成保存。`);
        result = await current.save(target.version);
      } else {
        if (!current.discard) return blocked("DRAFT_DISCARD_UNSUPPORTED", `请回到“${target.entityKey}”处理草稿。`);
        result = await current.discard(target.version);
      }
    } catch (error) {
      return blocked("DRAFT_ACTION_FAILED", `“${target.entityKey}”处理失败：${error instanceof Error ? error.message : String(error)}`);
    }
    if (result.status === "blocked") return blocked("DRAFT_ACTION_BLOCKED", result.reason);

    const acknowledgedVersion = action === "save" && result.status === "saved"
      ? result.savedVersion
      : action === "discard" && result.status === "discarded"
        ? result.discardedVersion
        : null;
    if (acknowledgedVersion !== target.version) {
      return blocked("DRAFT_ACK_MISMATCH", `“${target.entityKey}”的处理回执版本不匹配。`);
    }

    const latest = registry.get(target.ownerId);
    if (!latest || !sameIdentity(latest, target)) {
      return blocked("DRAFT_CHANGED_DURING_ACTION", `“${target.entityKey}”在处理期间发生变化，已保留新修改。`);
    }
    if (latest.dirty) return blocked("DRAFT_STILL_DIRTY", `“${target.entityKey}”仍有未保存内容。`);
    completedOwnerIds.push(target.ownerId);
  }

  const remaining = registry.getDirty();
  if (remaining.length > 0) {
    return blocked("NEW_DRAFT_PENDING", `仍有未处理内容：${remaining.map((owner) => owner.entityKey).join("、")}。`);
  }
  return { allowed: true, completedOwnerIds };
}
