// Standalone checks of the reference coordinator; NOT application integration tests.
const assert = require('node:assert/strict');
const { settleDirtyDrafts } = require('./build/settleDirtyDrafts.reference.js');
function fixture() {
  const map = new Map();
  const registry = { get: id => map.get(id), getDirty: () => [...map.values()].filter(x => x.dirty) };
  const patch = (id, updates) => map.set(id, { ...map.get(id), ...updates });
  const add = (id, updates = {}) => map.set(id, {
    ownerId: id, entityKey: id, registrationToken: id + '-token', version: 1, dirty: true,
    save: async version => { patch(id, { dirty: false }); return { status: 'saved', savedVersion: version }; },
    discard: async version => { patch(id, { dirty: false }); return { status: 'discarded', discardedVersion: version }; },
    ...updates,
  });
  return { map, registry, patch, add };
}
const cases = [
 ['all saved', async () => { const f=fixture(); f.add('A'); f.add('B'); assert.equal((await settleDirtyDrafts(f.registry,'save')).allowed,true); }],
 ['A redirtied while saving B', async () => { const f=fixture(); f.add('A'); f.add('B',{save:async v=>{f.patch('A',{dirty:true,version:2}); f.patch('B',{dirty:false}); return {status:'saved',savedVersion:v};}}); const r=await settleDirtyDrafts(f.registry,'save'); assert.equal(r.allowed,false); assert.equal(r.code,'NEW_DRAFT_PENDING'); assert.equal(f.map.get('A').dirty,true); }],
 ['new owner while saving', async () => { const f=fixture(); f.add('A',{save:async v=>{f.add('C');f.patch('A',{dirty:false});return {status:'saved',savedVersion:v};}}); assert.equal((await settleDirtyDrafts(f.registry,'save')).allowed,false); }],
 ['wrong acknowledgement', async () => {const f=fixture();f.add('A',{save:async()=>({status:'saved',savedVersion:0})});assert.equal((await settleDirtyDrafts(f.registry,'save')).code,'DRAFT_ACK_MISMATCH');}],
 ['same owner new edit', async () => {const f=fixture();f.add('A',{save:async v=>{f.patch('A',{version:2});return {status:'saved',savedVersion:v};}});assert.equal((await settleDirtyDrafts(f.registry,'save')).code,'DRAFT_CHANGED_DURING_ACTION');}],
 ['owner unmounted during save', async () => {const f=fixture();f.add('A',{save:async v=>{f.map.delete('A');return {status:'saved',savedVersion:v};}});assert.equal((await settleDirtyDrafts(f.registry,'save')).allowed,false);}],
 ['missing save callback', async () => {const f=fixture();f.add('A',{save:undefined});assert.equal((await settleDirtyDrafts(f.registry,'save')).code,'DRAFT_SAVE_UNSUPPORTED');}],
 ['exception is contained', async () => {const f=fixture();f.add('A',{save:async()=>{throw Error('offline');}});assert.equal((await settleDirtyDrafts(f.registry,'save')).code,'DRAFT_ACTION_FAILED');}],
 ['use latest callback for second owner', async () => {const f=fixture();let latestCalled=false;f.add('A',{save:async v=>{f.patch('A',{dirty:false});f.patch('B',{save:async v=>{latestCalled=true;f.patch('B',{dirty:false});return {status:'saved',savedVersion:v};}});return {status:'saved',savedVersion:v};}});f.add('B',{save:async()=>{throw Error('stale callback');}});assert.equal((await settleDirtyDrafts(f.registry,'save')).allowed,true);assert.equal(latestCalled,true);}],
 ['discard all', async () => {const f=fixture();f.add('A');f.add('B');assert.equal((await settleDirtyDrafts(f.registry,'discard')).allowed,true);}],
 ['claim success but still dirty', async () => {const f=fixture();f.add('A',{save:async v=>({status:'saved',savedVersion:v})});assert.equal((await settleDirtyDrafts(f.registry,'save')).code,'DRAFT_STILL_DIRTY');}],
 ['token changed during action', async () => {const f=fixture();f.add('A',{save:async v=>{f.patch('A',{registrationToken:'new',dirty:false});return {status:'saved',savedVersion:v};}});assert.equal((await settleDirtyDrafts(f.registry,'save')).allowed,false);}],
];
(async()=>{for(const [name,run] of cases){await run();console.log('PASS '+name);}console.log(`${cases.length} reference checks passed. Application integration has NOT been tested.`);})().catch(e=>{console.error(e);process.exitCode=1;});
